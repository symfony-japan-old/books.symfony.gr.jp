Symfony楽団ホームページからのお問い合わせがありました。

■お名前
<?php echo $name ?>

■メールアドレス
<?php echo $email ?>

■お問い合わせ内容
<?php echo $body ?>

■入団希望
<?php echo InquiryForm::$joinChoices[$join] ?>

